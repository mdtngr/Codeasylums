# Big_Mart_Sales_Prediction
Algorithm Applied -> Random Forest Regressor     

Accuracy -> 91.6%

